package com.example.monthly_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Informacje extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacje);
    }
}